# Steady

Steady is a free web app that offers calm, evidence-based support for anxiety and panic. Every piece of clinical guidance links to the published source it came from (NIMH, NHS, NICE, APA, SAMHSA, NCCIH, CDC, Mayo Clinic and others).

> Steady is not a diagnosis, treatment, or substitute for care from a licensed professional. In a medical emergency call **911**. For a suicidal or mental health crisis call or text **988**.

## Features

- **I Need Help Now:** a full-screen calm mode with:
  - Breathing with no breath-holding.
  - 5-4-3-2-1 grounding.
  - Calming sounds with animated rain, ocean and campfire scenes, plus users' own uploaded sounds.
  - Loved ones' recorded voice messages.
  - A trusted contact.
  - Crisis lines.
  - An emergency symptoms guide.
- **Talk it through:** an AI support assistant that answers only from the knowledge library, cites its sources, and has crisis safeguards and a read-aloud option.
- **Mood journal:** entries with date, time, mood, anxiety level, feelings and what helped, shown on a monthly calendar.
- **Natural ways to feel better:** practices with their evidence and limitations.
- **Pregnancy & postpartum** and **Support groups** sections.
- **Spiritual wellness (optional):** Christian resources, plus a nonreligious option.
- **Find a licensed therapist:** a live NPI Registry search with a distance map, plus links to directories.
- **Knowledge library:** every source, with dates and links.

## Files

| File | What it is |
| --- | --- |
| `index.html` | The whole app (HTML, CSS and JavaScript in one file) |
| `zips.json` | ZIP code center points, used for therapist distances (U.S. Census Bureau ZCTA data, via the MIT-licensed `us-zips` package) |
| `basemap.json` | Coastline, state and county lines for the map (U.S. Census Bureau 2017 cartographic boundaries, via `us-atlas`) |
| `.nojekyll` | Tells GitHub Pages to serve the files as they are |

## Run it on your computer

The app loads `zips.json` and `basemap.json`, so open it through a small local web server rather than double-clicking `index.html`:

```bash
cd steady-app
python3 -m http.server 8000
```

Then open http://localhost:8000 in your browser.

## Publish with GitHub Pages

1. Push this folder to a GitHub repository.
2. In the repository, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
4. Choose the **main** branch and the **/ (root)** folder, then click **Save**.
5. After a minute or two, your site appears at `https://<your-username>.github.io/<repository-name>/`.

## What works outside Claude

Everything runs in the user's own browser, except two features that currently depend on Claude's artifact platform:

| Feature | Outside Claude today | To make it work for everyone |
| --- | --- | --- |
| AI assistant | Shows "not available in this view" | Add a serverless function (for example, Cloudflare Workers) that calls an AI API with your key, keeping the key off the browser |
| Live NPI therapist search | Shows "Provider search unavailable"; the directory links still work | Add a serverless function that calls the NPI Registry API (`https://npiregistry.cms.hhs.gov/api/?version=2.1`) |

Other planned items:

- Tap-to-talk voice input (a placeholder is in the code).
- A street map with tile service.
- A journal export.

## Privacy

Journal entries, voice messages, custom sounds, the trusted contact and settings are saved only in the user's browser, using IndexedDB and localStorage. Nothing is uploaded, and there is no tracking or analytics.

## Data and content sources

- Clinical content: see the in-app Knowledge Library (entries L1–L27), which lists each publisher, date and link.
- NPI Registry: CMS National Plan and Provider Enumeration System. Having an NPI doesn't confirm a current license, so verify licenses with state boards.
- Maps and distances: U.S. Census Bureau ZIP Code Tabulation Areas and cartographic boundary files.
